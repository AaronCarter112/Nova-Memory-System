"""
Response generation using DSPy + LiteLLM + Ollama.
"""
import dspy
from mem.generate_embeddings import generate_embeddings
from mem.vectordb import search_memories, stringify_retrieved_point

# Configure DSPy to use Ollama's OpenAI-compatible endpoint
# Model format: ollama_chat/<model_name> for LiteLLM
# api_base: Ollama's /v1 endpoint (port 11434 by default)
# api_key: Required by LiteLLM but ignored by Ollama
nova_model = dspy.LM(
    model="openai/Dolphin3:latest",  # Use openai/ prefix for Ollama with custom base_url
    api_base="http://127.0.0.1:11434/v1/",
    api_key="ollama",  # Dummy key required by LiteLLM
    temperature=0.7,  # Optional: adjust for creativity
    max_tokens=800,   # Optional: max response length
)


class NovaResponseSignature(dspy.Signature):
    """
    You are Nova, a witty and empathetic AI companion.

    You see:
    - transcript: recent messages in the chat.
    - memories: a list of relevant long-term memories retrieved from Qdrant.
    
    Use memories to personalize your reply and make the user feel remembered.
    If multiple memories conflict (e.g., different locations), assume the one
    with the latest date is the most up to date.

    Set save_memory=True only when the user shares a new, stable personal fact
    (like their name, location, job, preferences, or ongoing projects).
    Do NOT set save_memory=True for casual chit-chat or transient statements.
    """
    
    transcript: list[dict] = dspy.InputField(
        desc="Recent messages in the chat, excluding the current user message."
    )
    memories: list[dict] = dspy.InputField(
        desc=(
            "Relevant memories as dicts with keys: text, categories, date, "
            "score, fact_key."
        )
    )
    question: str = dspy.InputField(
        desc="The latest user question or message to respond to."
    )

    response: str = dspy.OutputField(
        desc="Your in-persona reply to the user."
    )
    save_memory: bool = dspy.OutputField(
        desc="True only if a new long-term memory should be saved."
    )


async def fetch_similar_memories_logic(
    search_text: str,
    user_id: int,
    limit: int = 3,
) -> list[dict]:
    """
    Fetch similar memories from Qdrant based on semantic search.
    
    Args:
        search_text: The text to search for (usually the user's latest message)
        user_id: The user's ID for filtering memories
        limit: Maximum number of memories to retrieve
        
    Returns:
        List of memory dicts with keys: text, categories, date, score, fact_key
    """
    try:
        # Generate embedding for the search text
        search_vector = (await generate_embeddings([search_text]))[0]
        
        # Search Qdrant for similar memories
        memories = await search_memories(
            search_vector,
            user_id=user_id,
            categories=None,  # Search across all categories
            limit=limit,
        )
        
        # Convert to dict format for LLM consumption
        return [stringify_retrieved_point(m) for m in memories]
    
    except Exception as e:
        print(f"❌ Error fetching memories: {e}")
        return []  # Return empty list on error to allow chat to continue
