from fastapi import FastAPI
from pydantic import BaseModel
from typing import List
import requests
import uvicorn

OLLAMA_URL = "http://localhost:11434"

app = FastAPI(title="Ollama OpenAI Proxy")


class ChatMessage(BaseModel):
    role: str
    content: str


class ChatRequest(BaseModel):
    model: str
    messages: List[ChatMessage]


@app.post("/v1/chat/completions")
def chat(req: ChatRequest):
    payload = {
        "model": req.model,
        "messages": [{"role": m.role, "content": m.content} for m in req.messages],
        "stream": True,
    }

    resp = requests.post(f"{OLLAMA_URL}/api/chat", json=payload, stream=True)
    resp.raise_for_status()

    full_content = ""

    for line in resp.iter_lines():
        if not line:
            continue
        try:
            chunk = line.decode("utf-8")
        except Exception:
            continue
        try:
            data = requests.utils.json.loads(chunk)
        except Exception:
            continue

        message = data.get("message") or {}
        content_piece = message.get("content") or ""
        full_content += content_piece

    return {
        "id": "ollama-chat-1",
        "object": "chat.completion",
        "choices": [
            {
                "index": 0,
                "message": {
                    "role": "assistant",
                    "content": full_content,
                },
                "finish_reason": "stop",
            }
        ],
        "usage": {
            "prompt_tokens": 0,
            "completion_tokens": 0,
            "total_tokens": 0,
        },
    }


if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=11435)
