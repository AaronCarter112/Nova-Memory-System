import os
import requests

OLLAMA_BASE_URL = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
EMBEDDING_MODEL = os.getenv("EMBEDDING_MODEL", "nomic-embed-text:latest")
EMBEDDING_DIM = int(os.getenv("EMBEDDING_DIM", "768"))


async def generate_embeddings(strings: list[str]):
    """
    Generate embeddings using Ollama's /api/embeddings endpoint.

    Returns: list[list[float]] with length EMBEDDING_DIM for each string.
    On error, returns a zero-vector of EMBEDDING_DIM.
    """
    embeddings: list[list[float]] = []
    for text in strings:
        try:
            response = requests.post(
                f"{OLLAMA_BASE_URL}/api/embeddings",
                json={"model": EMBEDDING_MODEL, "prompt": text},
                timeout=30,
            )
            response.raise_for_status()
            data = response.json()
            embeddings.append(data["embedding"])
        except Exception as e:
            print(f"Embedding Error: {e}")
            embeddings.append([0.0] * EMBEDDING_DIM)
    return embeddings
