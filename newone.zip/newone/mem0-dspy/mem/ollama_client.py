import requests

class SimpleOllamaChat:
    """
    Minimal client to call Ollama's /api/chat endpoint.

    It implements a __call__(prompt) method so DSPy can use it as an LM.
    """

    def __init__(self, model: str, base_url: str = "http://localhost:11434"):
        self.model = model
        self.base_url = base_url.rstrip("/")

    def __call__(self, prompt: str, stop: str | None = None) -> str:
        payload = {
            "model": self.model,
            "messages": [{"role": "user", "content": prompt}],
            "stream": False,
        }
        resp = requests.post(
            f"{self.base_url}/api/chat",
            json=payload,
            timeout=120,
        )
        resp.raise_for_status()
        data = resp.json()

        content = ""
        if isinstance(data, dict) and "message" in data:
            content = data["message"].get("content", "") or ""

        if stop and stop in content:
            content = content.split(stop)[0]

        return content
