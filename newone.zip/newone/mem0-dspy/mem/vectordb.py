"""
Enhanced vector database operations with semantic deduplication for Nova.

Features:
- Semantic similarity checking to prevent duplicate memories
- Category and fact_key filtering
- Memory management (delete, search, list)
"""

from __future__ import annotations

import os
from typing import Optional, List
from uuid import uuid4

from pydantic import BaseModel
from qdrant_client import AsyncQdrantClient
from qdrant_client.models import Distance, Filter, VectorParams, models, MatchValue


def _qdrant_url() -> str:
    # Supports either QDRANT_URL or HOST/PORT
    url = os.getenv("QDRANT_URL")
    if url:
        return url
    host = os.getenv("QDRANT_HOST", "localhost")
    port = os.getenv("QDRANT_PORT", "6333")
    return f"http://{host}:{port}"


client = AsyncQdrantClient(url=_qdrant_url())
COLLECTION_NAME = "nova_memories"

# If you know your embedding size (nomic-embed-text is 768), set it here.
EMBEDDING_DIM = int(os.getenv("EMBEDDING_DIM", "768"))

# Semantic similarity threshold for duplicate detection
DUPLICATE_THRESHOLD = float(os.getenv("DUPLICATE_THRESHOLD", "0.90"))

# Fixed category ontology for Nova
ALLOWED_CATEGORIES = [
    "personal_details",
    "user_preferences",
    "projects",
    "routines",
    "meta",
    "general",
]


def normalize_categories(cats: Optional[list[str]]) -> list[str]:
    if not cats:
        return ["general"]
    norm: list[str] = []
    for c in cats:
        if not c:
            continue
        c = c.strip().lower()
        if c in ALLOWED_CATEGORIES:
            norm.append(c)
    return norm or ["general"]


class EmbeddedMemory(BaseModel):
    """Memory with embedding vector, categories, and a stable fact_key."""
    user_id: int
    memory_text: str
    categories: list[str]
    date: str
    embedding: list[float]
    fact_key: str = "other.misc"  # used for dedup/update of updatable facts


class RetrievedMemory(BaseModel):
    """Memory retrieved from search or scroll."""
    point_id: str
    user_id: int
    memory_text: str
    categories: list[str]
    date: str
    score: float = 0.0
    fact_key: str = "other.misc"


async def create_memory_collection():
    """Create Qdrant collection with category + fact_key support."""
    try:
        exists = await client.collection_exists(COLLECTION_NAME)

        if not exists:
            await client.create_collection(
                collection_name=COLLECTION_NAME,
                vectors_config=VectorParams(
                    size=EMBEDDING_DIM,
                    distance=Distance.COSINE,
                ),
            )

            # Index user_id for filtering
            await client.create_payload_index(
                collection_name=COLLECTION_NAME,
                field_name="user_id",
                field_schema=models.PayloadSchemaType.INTEGER,
            )

            # Index categories for keyword filtering
            await client.create_payload_index(
                collection_name=COLLECTION_NAME,
                field_name="categories",
                field_schema=models.PayloadSchemaType.KEYWORD,
            )

            # Index fact_key for exact-match update/dedup
            await client.create_payload_index(
                collection_name=COLLECTION_NAME,
                field_name="fact_key",
                field_schema=models.PayloadSchemaType.KEYWORD,
            )

            print(f"✅ Collection '{COLLECTION_NAME}' created (dim={EMBEDDING_DIM})")
        else:
            print(f"ℹ️  Collection '{COLLECTION_NAME}' already exists")
    except Exception as e:
        print(f"❌ Error creating collection: {e}")
        raise


async def check_for_semantic_duplicates(
    user_id: int,
    embedding: list[float],
    category: str,
    threshold: float = DUPLICATE_THRESHOLD,
    limit: int = 3,
) -> list[RetrievedMemory]:
    """
    Check if a very similar memory already exists.
    Returns memories above the similarity threshold.
    """
    try:
        result = await client.query_points(
            collection_name=COLLECTION_NAME,
            query=embedding,
            with_payload=True,
            query_filter=Filter(
                must=[
                    models.FieldCondition(
                        key="user_id",
                        match=models.MatchValue(value=user_id),
                    ),
                    models.FieldCondition(
                        key="categories",
                        match=models.MatchAny(any=[category]),
                    ),
                ]
            ),
            score_threshold=threshold,
            limit=limit,
        )
        
        return [_convert_to_retrieved_memory(p) for p in result.points]
        
    except Exception as e:
        print(f"❌ Error checking duplicates: {e}")
        return []


async def insert_memories(memories: List[EmbeddedMemory]):
    """Insert memories with categories and fact_key."""
    try:
        await client.upsert(
            collection_name=COLLECTION_NAME,
            points=[
                models.PointStruct(
                    id=uuid4().hex,
                    payload={
                        "user_id": m.user_id,
                        "memory_text": m.memory_text,
                        "categories": normalize_categories(m.categories),
                        "date": m.date,
                        "fact_key": m.fact_key or "other.misc",
                    },
                    vector=m.embedding,
                )
                for m in memories
            ],
        )
    except Exception as e:
        print(f"❌ Error inserting memories: {e}")
        raise


async def delete_records(point_ids: list[str]):
    """Delete memories by point IDs."""
    try:
        await client.delete(
            collection_name=COLLECTION_NAME,
            points_selector=models.PointIdsList(points=point_ids),
        )
        print(f"🗑️  Deleted {len(point_ids)} memory/memories")
    except Exception as e:
        print(f"❌ Error deleting records: {e}")
        raise


async def delete_memories_by_text_match(
    user_id: int,
    search_text: str,
    embedding: list[float],
    threshold: float = 0.85,
) -> int:
    """
    Delete memories that match the search text semantically.
    Returns number of deleted memories.
    """
    try:
        # Find similar memories
        matches = await search_memories(
            search_vector=embedding,
            user_id=user_id,
            categories=None,
            limit=10,
            score_threshold=threshold,
        )
        
        if not matches:
            return 0
        
        # Delete them
        point_ids = [m.point_id for m in matches]
        await delete_records(point_ids)
        
        return len(point_ids)
        
    except Exception as e:
        print(f"❌ Error deleting by text match: {e}")
        return 0


async def fetch_by_fact_key(user_id: int, fact_key: str) -> list[RetrievedMemory]:
    """Fetch all memories for a user matching an exact fact_key."""
    try:
        if not fact_key:
            return []

        result = await client.scroll(
            collection_name=COLLECTION_NAME,
            scroll_filter=Filter(
                must=[
                    models.FieldCondition(
                        key="user_id",
                        match=models.MatchValue(value=user_id),
                    ),
                    models.FieldCondition(
                        key="fact_key",
                        match=models.MatchValue(value=fact_key),
                    ),
                ]
            ),
            limit=50,
            with_payload=True,
            with_vectors=False,
        )
        return [_convert_to_retrieved_memory(p) for p in result[0]]
    except Exception as e:
        print(f"❌ Error fetching by fact_key: {e}")
        return []


async def search_memories(
    search_vector: list[float],
    user_id: int,
    categories: Optional[list[str]] = None,
    limit: int = 3,
    score_threshold: float = 0.25,
) -> list[RetrievedMemory]:
    """Vector similarity search with optional category filtering."""
    try:
        must_conditions = [
            models.FieldCondition(
                key="user_id", match=models.MatchValue(value=user_id)
            )
        ]

        if categories:
            must_conditions.append(
                models.FieldCondition(
                    key="categories",
                    match=models.MatchAny(any=normalize_categories(categories)),
                )
            )

        query_filter = Filter(must=must_conditions)

        result = await client.query_points(
            collection_name=COLLECTION_NAME,
            query=search_vector,
            with_payload=True,
            query_filter=query_filter,
            score_threshold=score_threshold,
            limit=limit,
        )

        return [_convert_to_retrieved_memory(p) for p in result.points]
    except Exception as e:
        print(f"❌ Error searching memories: {e}")
        return []


async def fetch_all_user_memories(user_id: int) -> list[RetrievedMemory]:
    """Fetch all memories for a user."""
    try:
        result = await client.scroll(
            collection_name=COLLECTION_NAME,
            scroll_filter=Filter(
                must=[
                    models.FieldCondition(
                        key="user_id",
                        match=models.MatchValue(value=user_id),
                    )
                ]
            ),
            limit=1000,
            with_payload=True,
            with_vectors=False,
        )
        return [_convert_to_retrieved_memory(p) for p in result[0]]
    except Exception as e:
        print(f"❌ Error fetching all memories: {e}")
        return []


async def get_memory_count(user_id: int) -> int:
    """Get memory count for a user."""
    try:
        result = await client.count(
            collection_name=COLLECTION_NAME,
            count_filter=Filter(
                must=[
                    models.FieldCondition(
                        key="user_id",
                        match=models.MatchValue(value=user_id),
                    )
                ]
            ),
        )
        return result.count
    except Exception as e:
        print(f"❌ Error counting memories: {e}")
        return 0


async def get_all_categories(user_id: int) -> list[str]:
    """Get all unique categories for a user using facet."""
    try:
        facet = await client.facet(
            collection_name=COLLECTION_NAME,
            key="categories",
            facet_filter=Filter(
                must=[
                    models.FieldCondition(
                        key="user_id",
                        match=models.MatchValue(value=user_id),
                    )
                ]
            ),
            limit=1000,
        )
        # Normalize + dedupe
        return sorted(
            {
                str(hit.value).strip().lower()
                for hit in facet.hits
                if hit.value
            }
        )
    except Exception as e:
        print(f"❌ Error fetching categories: {e}")
        return []


def _convert_to_retrieved_memory(point) -> RetrievedMemory:
    payload = point.payload or {}
    return RetrievedMemory(
        point_id=point.id,
        user_id=payload["user_id"],
        memory_text=payload["memory_text"],
        categories=payload.get("categories", []),
        date=payload["date"],
        score=getattr(point, "score", 0.0) or 0.0,
        fact_key=payload.get("fact_key", "other.misc") or "other.misc",
    )


def stringify_retrieved_point(m: RetrievedMemory) -> dict:
    """
    Return a dict so the LLM and frontend can see structured memory fields.
    """
    return {
        "date": m.date,
        "categories": m.categories,
        "text": m.memory_text,
        "score": m.score,
        "fact_key": m.fact_key,
    }
