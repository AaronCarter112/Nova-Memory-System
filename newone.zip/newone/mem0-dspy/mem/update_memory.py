"""
Enhanced memory update logic with semantic deduplication.
Prevents saving the same memory multiple times.
"""
from __future__ import annotations

import dspy
from datetime import datetime

from mem.generate_embeddings import generate_embeddings
from mem.vectordb import (
    EmbeddedMemory,
    insert_memories,
    normalize_categories,
    fetch_by_fact_key,
    delete_records,
    check_for_semantic_duplicates,
)

# Configure DSPy LM for memory extraction logic
memory_logic_lm = dspy.LM(
    model="openai/Dolphin3:latest",
    api_base="http://127.0.0.1:11434/v1/",
    api_key="ollama",
    temperature=0.3,  # Lower temperature for more consistent extraction
    max_tokens=500,
)


class UpdateMemorySignature(dspy.Signature):
    """
    Analyze the recent chat history. If the user provided a personal fact
    (like their name, a preference, a project they are working on, or a routine),
    summarize it into a single factual sentence for long-term storage.

    Only extract stable, long-lived facts (identity, preferences, projects, routines),
    not transient chit-chat or casual remarks.

    Guidelines for fact_key:
    - Use 'profile.name' for the user's name
    - Use 'profile.location.current' for where the user currently lives
    - Use 'profile.employer.current' for current job/company
    - Use 'profile.relationship_status' for relationship status
    - Use 'profile.pet.<pet_name>' for pets
    - For preferences, hobbies, and projects that can coexist, 
      set fact_key to 'other.misc' so multiple memories can be saved
    
    Examples:
    - "My name is Alice" → fact_key='profile.name'
    - "I live in Toronto" → fact_key='profile.location.current'
    - "I work at Anthropic" → fact_key='profile.employer.current'
    - "I love playing guitar" → fact_key='other.misc' (hobby)
    - "I'm working on a Python chatbot" → fact_key='other.misc' (project)
    """
    
    messages: list[dict] = dspy.InputField(
        desc="The last few turns of the conversation in OpenAI-style {role, content} format."
    )

    thought: str = dspy.OutputField(
        desc="Your reasoning about whether there is a new fact to save."
    )
    new_memory_text: str = dspy.OutputField(
        desc=(
            "A single factual sentence to save, or 'None' if nothing new, "
            "uncertain, or too transient was shared."
        )
    )
    category: str = dspy.OutputField(
        desc=(
            "One of: personal_details, user_preferences, projects, routines, general. "
            "Choose the best fit for the new_memory_text."
        )
    )
    fact_key: str = dspy.OutputField(
        desc=(
            "A stable key for this fact if it should override older ones "
            "(e.g., 'profile.location.current'), or 'other.misc' if multiple "
            "instances should coexist."
        )
    )


async def update_memories(user_id: int, messages: list[dict]) -> bool:
    """
    Extract and save new memories from recent conversation.
    Includes semantic deduplication to prevent saving the same memory multiple times.
    
    Args:
        user_id: The user's ID
        messages: Recent chat messages (typically last 4-6 messages)
        
    Returns:
        True if a memory was saved, False otherwise
    """
    try:
        # Create predictor for memory extraction
        predictor = dspy.Predict(UpdateMemorySignature)

        # Use memory_logic_lm within this context
        with dspy.context(lm=memory_logic_lm):
            out = await predictor.acall(messages=messages)

        # Extract the new memory text
        text = (out.new_memory_text or "").strip()

        # Check if there's actually a memory to save
        if not text or text.lower() == "none" or len(text) < 5:
            print(f"🧠 NOVA THOUGHT: {out.thought}")
            print(f"ℹ️  No new memory to save")
            return False

        # Normalize category
        raw_cat = (out.category or "").strip().lower()
        cats = normalize_categories([raw_cat])
        category = cats[0]

        # Extract fact_key
        raw_key = (out.fact_key or "").strip()
        fact_key = raw_key if raw_key and raw_key.lower() != "none" else "other.misc"

        # Generate embedding for the new memory
        embeddings = await generate_embeddings([text])
        new_embedding = embeddings[0]

        print(f"🧠 NOVA THOUGHT: {out.thought}")

        # Check for semantic duplicates (only for other.misc)
        if fact_key == "other.misc":
            duplicates = await check_for_semantic_duplicates(
                user_id=user_id,
                embedding=new_embedding,
                category=category,
                threshold=0.90,  # 90% similarity threshold
                limit=3,
            )
            
            if duplicates:
                print(f"⚠️  DUPLICATE DETECTED: Similar memory already exists")
                print(f"   Existing: {duplicates[0].memory_text}")
                print(f"   New: {text}")
                print(f"   Similarity: {duplicates[0].score:.2%}")
                print(f"   ℹ️  Skipping save to prevent duplicate")
                return False

        # If this is an updatable fact (not other.misc), delete old versions
        if fact_key != "other.misc":
            existing = await fetch_by_fact_key(user_id, fact_key)
            if existing:
                print(f"🔄 Updating existing fact: {fact_key}")
                print(f"   Old: {existing[0].memory_text}")
                print(f"   New: {text}")
                await delete_records([m.point_id for m in existing])

        # Log what we're saving
        if fact_key != "other.misc":
            print(f"💾 NEW IDENTITY FACT [{fact_key}] [{category}] {text}")
        else:
            print(f"💾 NEW MEMORY [{category}] {text}")

        # Insert the new memory into Qdrant
        await insert_memories(
            [
                EmbeddedMemory(
                    user_id=user_id,
                    memory_text=text,
                    categories=cats,
                    date=datetime.now().strftime("%Y-%m-%d"),
                    embedding=new_embedding,
                    fact_key=fact_key,
                )
            ]
        )
        
        return True

    except Exception as e:
        print(f"❌ MEMORY UPDATE ERROR: {e}")
        import traceback
        traceback.print_exc()
        return False
