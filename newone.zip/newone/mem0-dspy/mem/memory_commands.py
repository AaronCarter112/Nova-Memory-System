"""
Memory management commands for Nova.
Handles special commands like forget, list, search, etc.
"""
from __future__ import annotations

import re
from typing import Optional, Tuple

from mem.generate_embeddings import generate_embeddings
from mem.vectordb import (
    delete_memories_by_text_match,
    fetch_all_user_memories,
    get_memory_count,
    get_all_categories,
    search_memories,
    delete_records,
)


# Command patterns
FORGET_PATTERNS = [
    r"forget (?:that |about )?(.+)",
    r"delete (?:the )?memory (?:of |about )?(.+)",
    r"remove (?:the )?memory (?:of |about )?(.+)",
    r"erase (?:that |about )?(.+)",
]

LIST_PATTERNS = [
    r"list (?:all |my )?memories",
    r"show (?:all |my )?memories",
    r"what do you (?:know|remember) about me",
    r"tell me what you remember",
]

SEARCH_PATTERNS = [
    r"search (?:for |my )?memories (?:about |for )?(.+)",
    r"find memories (?:about |for )?(.+)",
    r"what do you remember about (.+)",
]

COUNT_PATTERNS = [
    r"how many memories",
    r"memory count",
    r"count (?:my )?memories",
]

CLEAR_ALL_PATTERNS = [
    r"forget everything",
    r"delete all (?:my )?memories",
    r"clear (?:all )?(?:my )?memories",
    r"erase everything",
]


async def detect_memory_command(user_input: str, user_id: int) -> Tuple[bool, Optional[str]]:
    """
    Detect if user input is a memory management command.
    
    Returns:
        (is_command, response_text)
        - is_command: True if this was a command
        - response_text: The response to send to the user (or None if not a command)
    """
    text = user_input.lower().strip()
    
    # Check for FORGET command
    for pattern in FORGET_PATTERNS:
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            what_to_forget = match.group(1).strip()
            response = await handle_forget_command(user_id, what_to_forget)
            return True, response
    
    # Check for CLEAR ALL command
    for pattern in CLEAR_ALL_PATTERNS:
        if re.search(pattern, text, re.IGNORECASE):
            response = await handle_clear_all_command(user_id)
            return True, response
    
    # Check for LIST command
    for pattern in LIST_PATTERNS:
        if re.search(pattern, text, re.IGNORECASE):
            response = await handle_list_command(user_id)
            return True, response
    
    # Check for SEARCH command
    for pattern in SEARCH_PATTERNS:
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            search_query = match.group(1).strip()
            response = await handle_search_command(user_id, search_query)
            return True, response
    
    # Check for COUNT command
    for pattern in COUNT_PATTERNS:
        if re.search(pattern, text, re.IGNORECASE):
            response = await handle_count_command(user_id)
            return True, response
    
    # Not a command
    return False, None


async def handle_forget_command(user_id: int, what_to_forget: str) -> str:
    """
    Delete memories matching the given text.
    
    Args:
        user_id: User ID
        what_to_forget: Text describing what to forget
        
    Returns:
        Response message
    """
    try:
        # Generate embedding for the text to forget
        embedding = (await generate_embeddings([what_to_forget]))[0]
        
        # Delete similar memories (85% threshold)
        deleted_count = await delete_memories_by_text_match(
            user_id=user_id,
            search_text=what_to_forget,
            embedding=embedding,
            threshold=0.85,
        )
        
        if deleted_count > 0:
            return f"🗑️ Forgotten! I've removed {deleted_count} memory/memories about '{what_to_forget}'."
        else:
            return f"🤔 I don't have any memories matching '{what_to_forget}'."
            
    except Exception as e:
        print(f"❌ Error in forget command: {e}")
        return "❌ Sorry, I encountered an error trying to forget that."


async def handle_clear_all_command(user_id: int) -> str:
    """
    Delete ALL memories for a user (use with caution!).
    
    Args:
        user_id: User ID
        
    Returns:
        Response message
    """
    try:
        # Fetch all memories
        all_memories = await fetch_all_user_memories(user_id)
        
        if not all_memories:
            return "ℹ️ I don't have any memories to clear."
        
        # Delete all
        point_ids = [m.point_id for m in all_memories]
        await delete_records(point_ids)
        
        return f"🗑️ All cleared! I've forgotten everything ({len(all_memories)} memories). We're starting fresh."
        
    except Exception as e:
        print(f"❌ Error in clear all command: {e}")
        return "❌ Sorry, I encountered an error trying to clear memories."


async def handle_list_command(user_id: int) -> str:
    """
    List all memories for a user, organized by category.
    
    Args:
        user_id: User ID
        
    Returns:
        Response message with all memories
    """
    try:
        memories = await fetch_all_user_memories(user_id)
        
        if not memories:
            return "ℹ️ I don't have any memories about you yet. Start chatting and I'll remember important details!"
        
        # Organize by category
        by_category = {}
        for mem in memories:
            cat = mem.categories[0] if mem.categories else "general"
            if cat not in by_category:
                by_category[cat] = []
            by_category[cat].append(mem)
        
        # Build response
        response_parts = [f"📚 I have {len(memories)} memories about you:\n"]
        
        category_emojis = {
            "personal_details": "👤",
            "user_preferences": "💭",
            "projects": "🚀",
            "routines": "🔄",
            "meta": "🧠",
            "general": "📝",
        }
        
        for category, mems in sorted(by_category.items()):
            emoji = category_emojis.get(category, "📝")
            cat_name = category.replace("_", " ").title()
            response_parts.append(f"\n{emoji} **{cat_name}** ({len(mems)}):")
            
            for mem in mems:
                date = mem.date
                text = mem.memory_text
                response_parts.append(f"  • [{date}] {text}")
        
        return "\n".join(response_parts)
        
    except Exception as e:
        print(f"❌ Error in list command: {e}")
        return "❌ Sorry, I encountered an error retrieving memories."


async def handle_search_command(user_id: int, search_query: str) -> str:
    """
    Search for memories matching a query.
    
    Args:
        user_id: User ID
        search_query: What to search for
        
    Returns:
        Response message with matching memories
    """
    try:
        # Generate embedding for search
        embedding = (await generate_embeddings([search_query]))[0]
        
        # Search
        results = await search_memories(
            search_vector=embedding,
            user_id=user_id,
            categories=None,
            limit=10,
            score_threshold=0.3,
        )
        
        if not results:
            return f"🔍 No memories found matching '{search_query}'."
        
        # Build response
        response_parts = [f"🔍 Found {len(results)} memories about '{search_query}':\n"]
        
        for i, mem in enumerate(results, 1):
            score_pct = int(mem.score * 100)
            category = mem.categories[0] if mem.categories else "general"
            response_parts.append(
                f"{i}. [{category}] ({score_pct}% match) {mem.memory_text}"
            )
        
        return "\n".join(response_parts)
        
    except Exception as e:
        print(f"❌ Error in search command: {e}")
        return "❌ Sorry, I encountered an error searching memories."


async def handle_count_command(user_id: int) -> str:
    """
    Get count of memories and breakdown by category.
    
    Args:
        user_id: User ID
        
    Returns:
        Response message with memory statistics
    """
    try:
        count = await get_memory_count(user_id)
        
        if count == 0:
            return "ℹ️ I don't have any memories about you yet."
        
        categories = await get_all_categories(user_id)
        
        # Get breakdown
        all_mems = await fetch_all_user_memories(user_id)
        by_category = {}
        for mem in all_mems:
            cat = mem.categories[0] if mem.categories else "general"
            by_category[cat] = by_category.get(cat, 0) + 1
        
        # Build response
        response_parts = [f"📊 Memory Statistics:\n"]
        response_parts.append(f"Total memories: {count}")
        response_parts.append(f"\nBreakdown by category:")
        
        for cat, cnt in sorted(by_category.items(), key=lambda x: x[1], reverse=True):
            cat_name = cat.replace("_", " ").title()
            response_parts.append(f"  • {cat_name}: {cnt}")
        
        return "\n".join(response_parts)
        
    except Exception as e:
        print(f"❌ Error in count command: {e}")
        return "❌ Sorry, I encountered an error counting memories."
